"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Profile = {
  id: string;
  email: string;
  role: "parent" | "child";
};

export default function HomePage() {
  const [message, setMessage] = useState("불러오는 중...");

  useEffect(() => {
    const routeByRole = async () => {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        window.location.replace("/login");
        return;
      }

      const { data, error } = await supabase
        .from("profiles")
        .select("id, email, role")
        .eq("id", user.id)
        .maybeSingle();

      if (error || !data) {
        console.error("프로필 조회 오류:", error);
        setMessage("프로필을 불러올 수 없습니다.");
        return;
      }

      const profile = data as Profile;

      if (profile.role === "child") {
        window.location.replace("/personal/child-home");
        return;
      }

      window.location.replace("/personal");
    };

    routeByRole();
  }, []);

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-10">
      <div className="mx-auto max-w-4xl">
        <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          {message}
        </div>
      </div>
    </main>
  );
}