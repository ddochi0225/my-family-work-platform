"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("parent");

  const signUp = async () => {
    if (!email || !password) {
      alert("이메일과 비밀번호를 입력해주세요.");
      return;
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      alert(`회원가입 오류: ${error.message}`);
      return;
    }

    const user = data.user;

    if (!user) {
      alert("회원가입은 되었지만 사용자 정보를 가져오지 못했어요.");
      return;
    }

    const { error: profileError } = await supabase.from("profiles").insert({
      id: user.id,
      email,
      role,
    });

    if (profileError) {
      alert(`profiles 저장 오류: ${profileError.message}`);
      return;
    }

    alert("회원가입 완료!");
  };

  const signIn = async () => {
    if (!email || !password) {
      alert("이메일과 비밀번호를 입력해주세요.");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      alert(`로그인 오류: ${error.message}`);
      return;
    }

    alert("로그인 성공!");
    router.push("/");
    router.refresh();
  };

  const resetPassword = async () => {
    if (!email) {
      alert("비밀번호 재설정을 위해 이메일을 먼저 입력해주세요.");
      return;
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: "http://localhost:3000/reset-password",
    });

    if (error) {
      alert(`재설정 메일 오류: ${error.message}`);
      return;
    }

    alert("비밀번호 재설정 메일을 보냈어요.");
  };

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-16">
      <div className="mx-auto max-w-md rounded-2xl border border-gray-200 bg-white p-8 shadow-sm">
        <h1 className="text-3xl font-bold text-gray-900">
          로그인 / 회원가입
        </h1>
        <p className="mt-2 text-sm text-gray-600">
          nunu & nunu-mom 플랫폼에 접속합니다.
        </p>

        <div className="mt-8 space-y-4">
          <input
            type="email"
            className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-black"
            placeholder="이메일"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-black"
            placeholder="비밀번호"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              회원가입 계정 유형
            </label>
            <select
              className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-black"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              <option value="parent">부모 계정</option>
              <option value="child">아이 계정</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={signIn}
              className="rounded-xl bg-black px-4 py-3 text-white"
            >
              로그인
            </button>

            <button
              onClick={signUp}
              className="rounded-xl border border-gray-300 px-4 py-3"
            >
              회원가입
            </button>
          </div>

          <button
            onClick={resetPassword}
            className="w-full text-sm text-gray-600 underline underline-offset-4"
          >
            비밀번호를 잊으셨나요?
          </button>
        </div>
      </div>
    </main>
  );
}