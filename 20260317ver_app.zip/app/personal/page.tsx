"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import ChildSelector from "@/app/components/ChildSelector";
import TodayDashboard from "@/app/components/TodayDashboard";
import { supabase } from "@/lib/supabase";

type ProfileRow = {
  id: string;
  email: string;
  role: "parent" | "child";
  child_id?: string | null;
};

const parentSections = [
  {
    title: "아이 관리",
    description:
      "자녀 관리, 일정 등록, 시간표 확인, 용돈 관리, 할 일 관리까지 아이 생활을 한곳에서 관리할 수 있어요.",
    href: "/personal/parent/children",
    emoji: "👧",
    features: ["자녀 관리", "일정 관리", "시간표", "용돈 관리", "할 일 관리"],
  },
  {
    title: "부모 관리",
    description:
      "자녀의 용돈 요청을 확인하고 승인하거나 반려할 수 있어요.",
    href: "/personal/parent/allowance-requests",
    emoji: "👨‍👩‍👧",
    features: ["용돈 요청 승인", "요청 현황 확인", "반려 처리"],
  },
  {
    title: "내 관리",
    description:
      "내 일정, 할 일, 메모, 생활비 등 개인 기록을 따로 정리하고 관리할 수 있어요.",
    href: "/personal/me",
    emoji: "🧑",
    features: ["내 일정", "할 일", "메모", "생활비"],
  },
];

export default function PersonalPage() {
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<"parent" | "child" | null>(null);
  const [selectedChildId, setSelectedChildId] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchProfile();
  }, []);

  const sections = useMemo(() => parentSections, []);

  const fetchProfile = async () => {
    setLoading(true);
    setErrorMessage("");

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      setErrorMessage("로그인 정보를 확인하지 못했어요.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, role, child_id")
      .eq("id", user.id)
      .maybeSingle();

    if (error) {
      console.error(error);
      setErrorMessage("프로필 정보를 불러오지 못했어요.");
      setLoading(false);
      return;
    }

    const profile = data as ProfileRow | null;

    if (!profile) {
      setErrorMessage("프로필 정보가 없어요.");
      setLoading(false);
      return;
    }

    if (profile.role === "child") {
      window.location.href = "/personal/child-home";
      return;
    }

    setRole("parent");
    setLoading(false);
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-6xl">불러오는 중...</div>
      </main>
    );
  }

  if (errorMessage) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          <h1 className="text-3xl font-bold text-gray-900">개인 관리 홈</h1>
          <p className="mt-4 text-sm text-red-600">{errorMessage}</p>
        </div>
      </main>
    );
  }

  if (role !== "parent") return null;

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-6xl space-y-8">
        <section className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-2xl">
              <div className="inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700">
                Nunu Platform
              </div>

              <h1 className="mt-4 text-3xl font-bold text-gray-900">
                개인 관리 홈
              </h1>

              <p className="mt-3 text-sm leading-6 text-gray-600">
                아이와 나의 일정을 구분해서 관리하고, 생활 기록과 용돈 흐름까지
                한 번에 확인할 수 있어요.
              </p>

              <div className="mt-5 flex flex-wrap gap-2">
                <span className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700">
                  오늘 일정 확인
                </span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700">
                  오늘의 할 일 확인
                </span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700">
                  현재 용돈 확인
                </span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700">
                  부모 승인 관리
                </span>
              </div>
            </div>

            <div className="w-full max-w-sm space-y-3">
              <div className="rounded-2xl bg-gray-50 p-4">
                <p className="text-sm font-medium text-gray-700">자녀 선택</p>
                <p className="mt-1 text-xs text-gray-500">
                  홈 대시보드에 표시할 자녀를 선택해 주세요.
                </p>

                <div className="mt-3">
                  <ChildSelector
                    value={selectedChildId}
                    onChange={(id) => setSelectedChildId(id)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Link
                  href="/personal/parent/children"
                  className="rounded-2xl border border-gray-300 bg-white px-4 py-3 text-center text-sm font-medium text-gray-800 transition hover:bg-gray-50"
                >
                  아이 관리
                </Link>
                <Link
                  href="/personal/parent/allowance-requests"
                  className="rounded-2xl border border-gray-300 bg-white px-4 py-3 text-center text-sm font-medium text-gray-800 transition hover:bg-gray-50"
                >
                  부모 승인
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section>
          <TodayDashboard childId={selectedChildId} role="parent" />
        </section>

        <section className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {sections.map((section) => (
            <Link
              key={section.href}
              href={section.href}
              className="group rounded-3xl bg-white p-7 shadow-sm ring-1 ring-gray-100 transition hover:-translate-y-1 hover:shadow-md"
            >
              <div className="text-3xl">{section.emoji}</div>

              <h2 className="mt-4 text-2xl font-semibold text-gray-900">
                {section.title}
              </h2>

              <p className="mt-3 text-sm leading-6 text-gray-600">
                {section.description}
              </p>

              <div className="mt-5 flex flex-wrap gap-2">
                {section.features.map((feature) => (
                  <span
                    key={feature}
                    className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              <div className="mt-6 text-sm font-medium text-gray-900">
                바로가기 →
              </div>
            </Link>
          ))}
        </section>
      </div>
    </main>
  );
}