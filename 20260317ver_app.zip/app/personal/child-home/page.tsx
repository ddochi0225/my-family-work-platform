"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import TodayDashboard from "@/app/components/TodayDashboard";

type ProfileRow = {
  id: string;
  email: string;
  role: "parent" | "child";
  child_id?: string | null;
};

export default function ChildHomePage() {
  const [loading, setLoading] = useState(true);
  const [childId, setChildId] = useState("");
  const [email, setEmail] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    setLoading(true);
    setErrorMessage("");

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      setErrorMessage("로그인 정보가 없어요.");
      setLoading(false);
      return;
    }

    setEmail(user.email ?? "");

    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, role, child_id")
      .eq("id", user.id)
      .maybeSingle();

    if (error) {
      console.error(error);
      setErrorMessage("프로필 정보를 불러오지 못했어요.");
      setLoading(false);
      return;
    }

    const profile = data as ProfileRow | null;

    if (!profile) {
      setErrorMessage("프로필 정보가 없어요.");
      setLoading(false);
      return;
    }

    // ✅ child-home에서는 child를 다시 child-home으로 보내면 안 됨
    if (profile.role !== "child") {
      window.location.replace("/personal");
      return;
    }

    if (!profile.child_id) {
      setErrorMessage("연결된 자녀 정보가 없어요.");
      setLoading(false);
      return;
    }

    setChildId(profile.child_id);
    setLoading(false);
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-6xl">불러오는 중...</div>
      </main>
    );
  }

  if (errorMessage) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          <h1 className="text-2xl font-bold text-gray-900">자녀 홈</h1>
          <p className="mt-4 text-sm text-red-600">{errorMessage}</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-6xl space-y-8">
        <section className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">내 홈</h1>
              <p className="mt-3 text-sm text-gray-600">
                오늘 일정, 할 일, 포인트와 용돈 현황을 확인할 수 있어요.
              </p>
              <div className="mt-4 rounded-2xl bg-gray-50 px-4 py-3 text-sm text-gray-700">
                로그인: {email}
              </div>
            </div>

            <div className="grid w-full max-w-sm gap-3">
              <Link
                href="/personal/child/schedule"
                className="rounded-2xl border border-gray-300 bg-white px-4 py-3 text-center text-sm font-medium hover:bg-gray-50"
              >
                내 일정
              </Link>
              <Link
                href="/personal/child/todo"
                className="rounded-2xl border border-gray-300 bg-white px-4 py-3 text-center text-sm font-medium hover:bg-gray-50"
              >
                할 일 보기
              </Link>
              <Link
                href="/personal/child/allowance"
                className="rounded-2xl border border-gray-300 bg-white px-4 py-3 text-center text-sm font-medium hover:bg-gray-50"
              >
                내 용돈
              </Link>
            </div>
          </div>
        </section>

        <TodayDashboard childId={childId} role="child" />

        <section className="grid gap-6 md:grid-cols-3">
          <Link
            href="/personal/child/schedule"
            className="rounded-3xl bg-white p-7 shadow-sm ring-1 ring-gray-100"
          >
            <div className="text-3xl">📅</div>
            <h2 className="mt-4 text-2xl font-semibold text-gray-900">내 일정</h2>
            <p className="mt-3 text-sm text-gray-600">
              오늘 일정과 등록된 반복 일정을 확인해요.
            </p>
          </Link>

          <Link
            href="/personal/child/todo"
            className="rounded-3xl bg-white p-7 shadow-sm ring-1 ring-gray-100"
          >
            <div className="text-3xl">📝</div>
            <h2 className="mt-4 text-2xl font-semibold text-gray-900">할 일</h2>
            <p className="mt-3 text-sm text-gray-600">
              해야 할 일을 확인하고 완료하면 포인트를 적립해요.
            </p>
          </Link>

          <Link
            href="/personal/child/allowance"
            className="rounded-3xl bg-white p-7 shadow-sm ring-1 ring-gray-100"
          >
            <div className="text-3xl">💰</div>
            <h2 className="mt-4 text-2xl font-semibold text-gray-900">내 용돈</h2>
            <p className="mt-3 text-sm text-gray-600">
              지출을 기록하고 포인트로 용돈을 요청할 수 있어요.
            </p>
          </Link>
        </section>
      </div>
    </main>
  );
}