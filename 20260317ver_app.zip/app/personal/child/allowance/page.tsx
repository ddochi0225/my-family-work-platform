"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type ChildRow = {
  id: string;
  name: string;
  points: number;
  exchange_amount: number;
};

type AllowanceItemRow = {
  id: string;
  child_id: string;
  type: string;
  amount: number;
  title: string;
  memo: string | null;
  spent_at: string;
  created_at: string;
};

type AllowanceRequestRow = {
  id: string;
  child_id: string;
  request_points: number;
  allowance_amount: number;
  status: string;
  created_at: string;
};

export default function ChildAllowancePage() {
  const [children, setChildren] = useState<ChildRow[]>([]);
  const [selectedChildId, setSelectedChildId] = useState("");
  const [items, setItems] = useState<AllowanceItemRow[]>([]);
  const [requests, setRequests] = useState<AllowanceRequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingExpense, setSavingExpense] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("");
  const [spentAt, setSpentAt] = useState(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  });

  useEffect(() => {
    fetchChildren();
  }, []);

  useEffect(() => {
    if (!selectedChildId) {
      setItems([]);
      setRequests([]);
      return;
    }

    fetchAllowanceItems(selectedChildId);
    fetchAllowanceRequests(selectedChildId);
  }, [selectedChildId]);

  const selectedChild = useMemo(() => {
    return children.find((child) => child.id === selectedChildId) ?? null;
  }, [children, selectedChildId]);

  const totalExpense = useMemo(() => {
    return items.reduce((sum, item) => sum + Number(item.amount ?? 0), 0);
  }, [items]);

  const fetchChildren = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("children")
      .select("id, name, points, exchange_amount")
      .order("created_at", { ascending: true });

    if (error) {
      console.error(error);
      alert("자녀 정보를 불러오지 못했어요.");
      setLoading(false);
      return;
    }

    const rows = (data as ChildRow[]) ?? [];
    setChildren(rows);

    if (rows.length > 0) {
      setSelectedChildId(rows[0].id);
    }

    setLoading(false);
  };

  const fetchAllowanceItems = async (childId: string) => {
    const { data, error } = await supabase
      .from("allowance_items")
      .select("id, child_id, type, amount, title, memo, spent_at, created_at")
      .eq("child_id", childId)
      .order("spent_at", { ascending: false })
      .order("created_at", { ascending: false });

    if (error) {
      console.error(error);
      alert("지출 내역을 불러오지 못했어요.");
      return;
    }

    setItems((data as AllowanceItemRow[]) ?? []);
  };

  const fetchAllowanceRequests = async (childId: string) => {
    const { data, error } = await supabase
      .from("allowance_requests")
      .select("id, child_id, request_points, allowance_amount, status, created_at")
      .eq("child_id", childId)
      .order("created_at", { ascending: false });

    if (error) {
      console.error(error);
      alert("용돈 요청 내역을 불러오지 못했어요.");
      return;
    }

    setRequests((data as AllowanceRequestRow[]) ?? []);
  };

  const resetExpenseForm = () => {
    setTitle("");
    setAmount("");
    setMemo("");
  };

  const handleCreateExpense = async () => {
    if (!selectedChildId) {
      alert("먼저 자녀를 선택해 주세요.");
      return;
    }

    if (!title.trim()) {
      alert("지출 항목을 입력해 주세요.");
      return;
    }

    const parsedAmount = Number(amount);

    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      alert("금액은 0보다 큰 숫자로 입력해 주세요.");
      return;
    }

    setSavingExpense(true);

    const { error } = await supabase.from("allowance_items").insert({
      child_id: selectedChildId,
      type: "expense",
      amount: Math.floor(parsedAmount),
      title: title.trim(),
      memo: memo.trim() || null,
      spent_at: spentAt,
    });

    if (error) {
      console.error(error);
      alert("지출 등록에 실패했어요.");
      setSavingExpense(false);
      return;
    }

    await fetchAllowanceItems(selectedChildId);
    resetExpenseForm();
    setSavingExpense(false);
  };

  const handleDeleteExpense = async (id: string) => {
    if (!selectedChildId) return;

    const ok = window.confirm("이 지출 내역을 삭제할까요?");
    if (!ok) return;

    setDeletingId(id);

    const { error } = await supabase
      .from("allowance_items")
      .delete()
      .eq("id", id);

    if (error) {
      console.error(error);
      alert("지출 내역 삭제에 실패했어요.");
      setDeletingId(null);
      return;
    }

    await fetchAllowanceItems(selectedChildId);
    setDeletingId(null);
  };

  const handleRequestAllowance = async () => {
    if (!selectedChild) {
      alert("자녀 정보를 찾지 못했어요.");
      return;
    }

    if (selectedChild.points < 1000) {
      alert("1000P 이상 모아야 용돈 요청이 가능해요.");
      return;
    }

    setRequesting(true);

    const nextPoints = selectedChild.points - 1000;

    const { error: updateError } = await supabase
      .from("children")
      .update({ points: nextPoints })
      .eq("id", selectedChild.id);

    if (updateError) {
      console.error(updateError);
      alert("포인트 차감에 실패했어요.");
      setRequesting(false);
      return;
    }

    const { error: insertError } = await supabase
      .from("allowance_requests")
      .insert({
        child_id: selectedChild.id,
        request_points: 1000,
        allowance_amount: selectedChild.exchange_amount,
        status: "pending",
      });

    if (insertError) {
      console.error(insertError);
      alert("용돈 요청 저장에 실패했어요.");
      setRequesting(false);
      return;
    }

    setChildren((prev) =>
      prev.map((child) =>
        child.id === selectedChild.id ? { ...child, points: nextPoints } : child
      )
    );

    await fetchAllowanceRequests(selectedChild.id);
    setRequesting(false);
    alert("용돈 요청이 완료되었어요.");
  };

  const formatDate = (value: string | null) => {
    if (!value) return "-";
    return new Date(value).toLocaleDateString("ko-KR");
  };

  const formatDateTime = (value: string | null) => {
    if (!value) return "-";
    return new Date(value).toLocaleString("ko-KR");
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-5xl">불러오는 중...</div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">용돈 관리</h1>
            <p className="mt-2 text-sm text-gray-600">
              자녀의 지출을 기록하고, 포인트가 모이면 용돈을 요청할 수 있어요.
            </p>
          </div>

          <Link
            href="/personal"
            className="inline-flex rounded-xl border border-gray-300 bg-white px-4 py-2 text-sm hover:bg-gray-50"
          >
            홈으로 이동
          </Link>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
          <label className="mb-2 block text-sm font-medium text-gray-700">
            자녀 선택
          </label>
          <select
            value={selectedChildId}
            onChange={(e) => setSelectedChildId(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
          >
            {children.length === 0 ? (
              <option value="">등록된 자녀가 없어요</option>
            ) : (
              children.map((child) => (
                <option key={child.id} value={child.id}>
                  {child.name}
                </option>
              ))
            )}
          </select>
        </div>

        {selectedChild && (
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
              <p className="text-sm text-gray-500">현재 포인트</p>
              <p className="mt-2 text-3xl font-bold text-blue-600">
                {selectedChild.points}P
              </p>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
              <p className="text-sm text-gray-500">1000P 교환 금액</p>
              <p className="mt-2 text-3xl font-bold text-emerald-600">
                {selectedChild.exchange_amount.toLocaleString()}원
              </p>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
              <p className="text-sm text-gray-500">누적 지출</p>
              <p className="mt-2 text-3xl font-bold text-rose-500">
                {totalExpense.toLocaleString()}원
              </p>
            </div>
          </div>
        )}

        {selectedChild && (
          <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">용돈 요청</h2>
                <p className="mt-1 text-sm text-gray-500">
                  포인트가 1000P 이상이면 용돈을 요청할 수 있어요.
                </p>
              </div>

              <button
                onClick={handleRequestAllowance}
                disabled={selectedChild.points < 1000 || requesting}
                className={`rounded-2xl px-5 py-3 text-sm font-semibold text-white transition ${
                  selectedChild.points >= 1000 && !requesting
                    ? "bg-gray-900 hover:bg-gray-800"
                    : "cursor-not-allowed bg-gray-300"
                }`}
              >
                {requesting ? "요청 중..." : "1000P로 용돈 요청하기"}
              </button>
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
            <h2 className="text-lg font-semibold text-gray-900">지출 입력</h2>

            <div className="mt-4 grid gap-4">
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  지출 항목
                </label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="예: 문구점"
                  className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  금액
                </label>
                <input
                  type="number"
                  min={0}
                  step={1}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="예: 3000"
                  className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  날짜
                </label>
                <input
                  type="date"
                  value={spentAt}
                  onChange={(e) => setSpentAt(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  메모
                </label>
                <textarea
                  value={memo}
                  onChange={(e) => setMemo(e.target.value)}
                  rows={4}
                  placeholder="예: 공책이랑 연필 샀어요"
                  className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
                />
              </div>
            </div>

            <button
              onClick={handleCreateExpense}
              disabled={!selectedChildId || savingExpense}
              className={`mt-5 rounded-2xl px-5 py-3 text-sm font-semibold text-white transition ${
                !selectedChildId || savingExpense
                  ? "cursor-not-allowed bg-gray-300"
                  : "bg-gray-900 hover:bg-gray-800"
              }`}
            >
              {savingExpense ? "저장 중..." : "지출 등록"}
            </button>
          </section>

          <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
            <h2 className="text-lg font-semibold text-gray-900">용돈 요청 내역</h2>

            {requests.length === 0 ? (
              <p className="mt-4 text-sm text-gray-500">아직 요청 내역이 없어요.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {requests.map((item) => (
                  <div
                    key={item.id}
                    className="rounded-xl border border-gray-200 px-4 py-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium text-gray-900">
                          {item.request_points}P →{" "}
                          {item.allowance_amount.toLocaleString()}원
                        </p>
                        <p className="text-sm text-gray-500">
                          {formatDateTime(item.created_at)}
                        </p>
                      </div>

                      <span
                        className={`rounded-full px-3 py-1 text-xs font-medium ${
                          item.status === "pending"
                            ? "bg-yellow-100 text-yellow-700"
                            : item.status === "approved"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {item.status === "pending"
                          ? "대기중"
                          : item.status === "approved"
                          ? "승인"
                          : "완료"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">지출 내역</h2>
            <span className="rounded-full bg-rose-50 px-3 py-1 text-xs font-medium text-rose-600">
              {items.length}건
            </span>
          </div>

          {items.length === 0 ? (
            <p className="mt-4 text-sm text-gray-500">등록된 지출 내역이 없어요.</p>
          ) : (
            <div className="mt-4 space-y-3">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col gap-3 rounded-2xl border border-gray-200 p-4 sm:flex-row sm:items-start sm:justify-between"
                >
                  <div>
                    <p className="text-base font-semibold text-gray-900">
                      {item.title}
                    </p>
                    <p className="mt-1 text-sm text-gray-500">
                      날짜: {formatDate(item.spent_at)}
                    </p>
                    <p className="mt-1 text-sm font-medium text-rose-500">
                      - {item.amount.toLocaleString()}원
                    </p>
                    {item.memo && (
                      <div className="mt-3 rounded-xl bg-gray-50 px-3 py-3 text-sm text-gray-600">
                        {item.memo}
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => handleDeleteExpense(item.id)}
                    disabled={deletingId === item.id}
                    className={`rounded-xl px-3 py-2 text-sm font-medium ${
                      deletingId === item.id
                        ? "cursor-not-allowed bg-gray-100 text-gray-400"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    삭제
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}