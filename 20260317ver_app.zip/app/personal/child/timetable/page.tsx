"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import ChildSelector from "@/app/components/ChildSelector";
import ChildTopNav from "@/app/components/ChildTopNav";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

type Child = {
  id: string;
  name: string;
  created_at?: string;
};

type Schedule = {
  id: string;
  child_id: string | null;
  title: string;
  is_recurring: boolean;
  day_of_week: string | null;
  start_time: string | null;
  end_time: string | null;
  schedule_date: string | null;
  location: string | null;
  memo: string | null;
  color: string | null;
  created_at?: string;
};

type WeekDay = {
  key: string;
  label: string;
  date: Date;
  dateString: string;
};

type CalendarCell = {
  date: Date;
  dateString: string;
  inCurrentMonth: boolean;
};

const monthDayLabels = ["일", "월", "화", "수", "목", "금", "토"];
const weekDayLabels = ["월", "화", "수", "목", "금", "토", "일"];

const recurringDayMap: Record<string, number> = {
  일: 0,
  월: 1,
  화: 2,
  수: 3,
  목: 4,
  금: 5,
  토: 6,
};

function formatDate(date: Date) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatMonthDay(date: Date) {
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function formatTime(time: string | null) {
  if (!time) return "-";
  const parts = time.split(":");
  if (parts.length < 2) return time;
  return `${parts[0]}:${parts[1]}`;
}

function timeToMinutes(time: string | null) {
  if (!time) return 0;
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function compareSchedules(a: Schedule, b: Schedule) {
  return timeToMinutes(a.start_time) - timeToMinutes(b.start_time);
}

function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function getMonday(baseDate: Date) {
  const date = new Date(baseDate);
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function getMonthGrid(baseDate: Date): CalendarCell[] {
  const year = baseDate.getFullYear();
  const month = baseDate.getMonth();

  const firstDay = new Date(year, month, 1);
  const firstWeekday = firstDay.getDay();
  const startOffset = firstWeekday;

  const gridStart = new Date(year, month, 1 - startOffset);
  gridStart.setHours(0, 0, 0, 0);

  return Array.from({ length: 42 }).map((_, index) => {
    const date = addDays(gridStart, index);
    return {
      date,
      dateString: formatDate(date),
      inCurrentMonth: date.getMonth() === month,
    };
  });
}

function getColorClass(color: string | null) {
  switch (color) {
    case "pink":
      return "bg-pink-100 text-pink-700 border-pink-200";
    case "yellow":
      return "bg-yellow-100 text-yellow-700 border-yellow-200";
    case "blue":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "green":
      return "bg-green-100 text-green-700 border-green-200";
    case "purple":
      return "bg-purple-100 text-purple-700 border-purple-200";
    case "gray":
    default:
      return "bg-gray-100 text-gray-700 border-gray-200";
  }
}

export default function ChildTimetablePage() {
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string>("");
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [viewMode, setViewMode] = useState<"week" | "month">("week");
  const [currentWeekBase, setCurrentWeekBase] = useState(new Date());
  const [currentMonthBase, setCurrentMonthBase] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const todayString = useMemo(() => formatDate(new Date()), []);

  const weekStart = useMemo(() => getMonday(currentWeekBase), [currentWeekBase]);

  const weekDays = useMemo<WeekDay[]>(() => {
    return Array.from({ length: 7 }).map((_, index) => {
      const date = addDays(weekStart, index);
      return {
        key: `${index}-${formatDate(date)}`,
        label: weekDayLabels[index],
        date,
        dateString: formatDate(date),
      };
    });
  }, [weekStart]);

  const monthGrid = useMemo(
    () => getMonthGrid(currentMonthBase),
    [currentMonthBase]
  );

  const childNameMap = useMemo(() => {
    return Object.fromEntries(children.map((child) => [child.id, child.name]));
  }, [children]);

  const selectedChildName = useMemo(() => {
    if (!selectedChildId) return "선택 안 됨";
    return childNameMap[selectedChildId] || "선택된 자녀";
  }, [childNameMap, selectedChildId]);

  useEffect(() => {
    fetchChildren();
  }, []);

  useEffect(() => {
    if (!selectedChildId) {
      setSchedules([]);
      setLoading(false);
      return;
    }

    fetchSchedules();
    setSelectedDate(null);
  }, [selectedChildId]);

  async function fetchChildren() {
    const { data, error } = await supabase
      .from("children")
      .select("*")
      .order("created_at", { ascending: true });

    if (error) {
      console.error("자녀 조회 오류:", error);
      setMessage(`자녀 목록을 불러오지 못했습니다: ${error.message}`);
      return;
    }

    const childList = (data as Child[]) || [];
    setChildren(childList);

    setSelectedChildId((prev) => {
      if (prev) return prev;
      return childList[0]?.id || "";
    });
  }

  async function fetchSchedules() {
    if (!selectedChildId) return;

    setLoading(true);
    setMessage("");

    const { data, error } = await supabase
      .from("schedules")
      .select("*")
      .eq("child_id", selectedChildId)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("시간표 조회 오류:", error);
      setMessage(`시간표 데이터를 불러오지 못했습니다: ${error.message}`);
      setLoading(false);
      return;
    }

    setSchedules((data as Schedule[]) || []);
    setLoading(false);
  }

  const recurringSchedules = useMemo(() => {
    return schedules.filter((item) => item.is_recurring).sort(compareSchedules);
  }, [schedules]);

  const onceSchedules = useMemo(() => {
    return schedules.filter((item) => !item.is_recurring);
  }, [schedules]);

  const onceSchedulesThisWeek = useMemo(() => {
    const weekDates = new Set(weekDays.map((day) => day.dateString));

    return onceSchedules
      .filter((item) => item.schedule_date && weekDates.has(item.schedule_date))
      .sort((a, b) => {
        if ((a.schedule_date || "") < (b.schedule_date || "")) return -1;
        if ((a.schedule_date || "") > (b.schedule_date || "")) return 1;
        return compareSchedules(a, b);
      });
  }, [onceSchedules, weekDays]);

  const schedulesByDay = useMemo(() => {
    return weekDays.map((day) => {
      const recurring = recurringSchedules.filter(
        (item) => recurringDayMap[item.day_of_week || ""] === day.date.getDay()
      );

      const once = onceSchedulesThisWeek.filter(
        (item) => item.schedule_date === day.dateString
      );

      return {
        ...day,
        items: [...recurring, ...once].sort(compareSchedules),
      };
    });
  }, [weekDays, recurringSchedules, onceSchedulesThisWeek]);

  const weekRangeText = useMemo(() => {
    const start = weekDays[0]?.date;
    const end = weekDays[6]?.date;
    if (!start || !end) return "";

    return `${start.getFullYear()}.${start.getMonth() + 1}.${start.getDate()} ~ ${end.getFullYear()}.${end.getMonth() + 1}.${end.getDate()}`;
  }, [weekDays]);

  const monthTitle = useMemo(() => {
    const year = currentMonthBase.getFullYear();
    const month = currentMonthBase.getMonth() + 1;
    return `${year}년 ${month}월`;
  }, [currentMonthBase]);

  function moveWeek(diff: number) {
    setCurrentWeekBase((prev) => addDays(prev, diff * 7));
  }

  function goToThisWeek() {
    setCurrentWeekBase(new Date());
  }

  function moveMonth(diff: number) {
    setCurrentMonthBase((prev) => {
      const next = new Date(prev);
      next.setMonth(next.getMonth() + diff);
      return next;
    });
  }

  function goToThisMonth() {
    setCurrentMonthBase(new Date());
  }

  function getSchedulesForDate(dateString: string) {
    const date = new Date(`${dateString}T00:00:00`);
    const dayIndex = date.getDay();

    const recurring = recurringSchedules.filter(
      (item) => recurringDayMap[item.day_of_week || ""] === dayIndex
    );

    const once = onceSchedules.filter((item) => item.schedule_date === dateString);

    return [...recurring, ...once].sort(compareSchedules);
  }

  const selectedDateSchedules = selectedDate
    ? getSchedulesForDate(selectedDate)
    : [];

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">아이 시간표</h1>
            <p className="mt-2 text-gray-600">
              자녀별로 주간 시간표와 월간 캘린더를 확인할 수 있어요.
            </p>

            <ChildTopNav />
          </div>

          <div className="flex flex-col gap-3 md:items-end">
            <ChildSelector
              value={selectedChildId}
              onChange={(id) => {
                setSelectedChildId(id);
                setSelectedDate(null);
              }}
            />
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-[1fr_auto]">
          <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-gray-600">
              현재 선택:{" "}
              <span className="font-medium text-gray-900">
                {selectedChildName}
              </span>
            </p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setViewMode("week")}
                className={`rounded-xl px-4 py-2 text-sm ${
                  viewMode === "week"
                    ? "bg-black text-white"
                    : "border border-gray-300 bg-white hover:bg-gray-50"
                }`}
              >
                주간 보기
              </button>

              <button
                type="button"
                onClick={() => setViewMode("month")}
                className={`rounded-xl px-4 py-2 text-sm ${
                  viewMode === "month"
                    ? "bg-black text-white"
                    : "border border-gray-300 bg-white hover:bg-gray-50"
                }`}
              >
                월간 보기
              </button>
            </div>
          </div>
        </div>

        {message && <p className="mt-4 text-sm text-blue-600">{message}</p>}

        {!selectedChildId ? (
          <div className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <p className="text-gray-600">
              등록된 자녀가 없습니다. 먼저 자녀를 등록해 주세요.
            </p>
          </div>
        ) : loading ? (
          <div className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <p className="text-gray-600">불러오는 중...</p>
          </div>
        ) : viewMode === "week" ? (
          <div className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-xl font-semibold">주간 시간표</h2>
                <p className="mt-1 text-sm text-gray-600">{weekRangeText}</p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => moveWeek(-1)}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  이전 주
                </button>
                <button
                  type="button"
                  onClick={goToThisWeek}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  이번 주
                </button>
                <button
                  type="button"
                  onClick={() => moveWeek(1)}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  다음 주
                </button>
              </div>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-7">
              {schedulesByDay.map((day) => {
                const isToday = day.dateString === todayString;

                return (
                  <div
                    key={day.key}
                    className={`min-h-[260px] rounded-2xl border p-4 ${
                      isToday
                        ? "border-blue-300 bg-blue-50"
                        : "border-gray-200 bg-gray-50"
                    }`}
                  >
                    <div className="border-b border-gray-200 pb-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-semibold">{day.label}</p>
                        {isToday && (
                          <span className="rounded-full bg-blue-100 px-2 py-1 text-[11px] text-blue-700">
                            오늘
                          </span>
                        )}
                      </div>
                      <p className="mt-1 text-sm text-gray-500">
                        {formatMonthDay(day.date)}
                      </p>
                    </div>

                    <div className="mt-4 space-y-3">
                      {day.items.length === 0 ? (
                        <p className="text-sm text-gray-400">일정 없음</p>
                      ) : (
                        day.items.map((item) => (
                          <div
                            key={item.id}
                            className={`rounded-xl border px-3 py-3 text-sm ${getColorClass(
                              item.color
                            )}`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <p className="font-semibold">{item.title}</p>
                              <span className="shrink-0 text-[11px] opacity-80">
                                {item.is_recurring ? "반복" : "일회성"}
                              </span>
                            </div>

                            <p className="mt-1 text-xs opacity-80">
                              {formatTime(item.start_time)} ~{" "}
                              {formatTime(item.end_time)}
                            </p>

                            {item.location && (
                              <p className="mt-2 text-xs opacity-90">
                                📍 {item.location}
                              </p>
                            )}

                            {item.memo && (
                              <p className="mt-1 text-xs opacity-90">
                                {item.memo}
                              </p>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-8 rounded-2xl border border-gray-200 bg-white">
              <div className="border-b border-gray-200 px-6 py-4">
                <h3 className="text-lg font-semibold">이번 주 일회성 일정</h3>
                <p className="mt-1 text-sm text-gray-600">
                  이번 주 날짜가 지정된 일정만 따로 모아봤어요.
                </p>
              </div>

              <div className="px-6 py-4">
                {onceSchedulesThisWeek.length === 0 ? (
                  <p className="text-sm text-gray-500">
                    이번 주에 등록된 일회성 일정이 없습니다.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {onceSchedulesThisWeek.map((item) => (
                      <div
                        key={item.id}
                        className="rounded-xl border border-gray-200 p-4"
                      >
                        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                          <div>
                            <p className="font-semibold">{item.title}</p>
                            <p className="mt-1 text-sm text-gray-600">
                              날짜: {item.schedule_date || "-"}
                            </p>
                            <p className="mt-1 text-sm text-gray-600">
                              시간: {formatTime(item.start_time)} ~{" "}
                              {formatTime(item.end_time)}
                            </p>
                            {item.location && (
                              <p className="mt-1 text-sm text-gray-600">
                                📍 {item.location}
                              </p>
                            )}
                            {item.memo && (
                              <p className="mt-1 text-sm text-gray-700">
                                메모: {item.memo}
                              </p>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            <span
                              className={`inline-flex w-fit rounded-md border px-3 py-1 text-xs font-medium ${getColorClass(
                                item.color
                              )}`}
                            >
                              일회성 일정
                            </span>

                            <Link
                              href={`/personal/child/schedule?edit=${item.id}`}
                              className="rounded-lg border border-gray-300 bg-white px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                            >
                              수정하러 가기
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-xl font-semibold">월간 캘린더</h2>
                <p className="mt-1 text-sm text-gray-600">{monthTitle}</p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => moveMonth(-1)}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  이전 달
                </button>
                <button
                  type="button"
                  onClick={goToThisMonth}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  이번 달
                </button>
                <button
                  type="button"
                  onClick={() => moveMonth(1)}
                  className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
                >
                  다음 달
                </button>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-7 gap-2">
              {monthDayLabels.map((label) => (
                <div
                  key={label}
                  className="rounded-xl bg-gray-100 px-3 py-2 text-center text-sm font-medium text-gray-700"
                >
                  {label}
                </div>
              ))}
            </div>

            <div className="mt-2 grid grid-cols-7 gap-2">
              {monthGrid.map((cell) => {
                const daySchedules = getSchedulesForDate(cell.dateString);
                const isToday = cell.dateString === todayString;
                const isSelected = selectedDate === cell.dateString;

                return (
                  <button
                    key={cell.dateString}
                    type="button"
                    onClick={() => setSelectedDate(cell.dateString)}
                    className={`min-h-[140px] rounded-2xl border p-3 text-left transition hover:bg-blue-50 ${
                      isSelected
                        ? "border-blue-400 ring-2 ring-blue-200"
                        : isToday
                          ? "border-blue-300 bg-blue-50"
                          : cell.inCurrentMonth
                            ? "border-gray-200 bg-white"
                            : "border-gray-100 bg-gray-50 text-gray-400"
                    }`}
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-semibold">
                        {cell.date.getDate()}
                      </span>
                      {isToday && (
                        <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] text-blue-700">
                          오늘
                        </span>
                      )}
                    </div>

                    <div className="space-y-1">
                      {daySchedules.length === 0
                        ? null
                        : daySchedules.slice(0, 3).map((item) => (
                            <div
                              key={`${cell.dateString}-${item.id}`}
                              className={`rounded-md border px-2 py-1 text-[11px] ${getColorClass(
                                item.color
                              )}`}
                            >
                              <p className="truncate font-medium">{item.title}</p>
                              <p className="truncate opacity-80">
                                {formatTime(item.start_time)}
                              </p>
                            </div>
                          ))}

                      {daySchedules.length > 3 && (
                        <p className="text-[11px] text-gray-500">
                          +{daySchedules.length - 3}개 더 있음
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {selectedDate && (
              <div className="mt-8 rounded-2xl border border-gray-200 bg-gray-50 p-6">
                <h3 className="text-lg font-semibold">📅 {selectedDate} 일정</h3>

                {selectedDateSchedules.length === 0 ? (
                  <p className="mt-3 text-sm text-gray-500">
                    등록된 일정이 없습니다.
                  </p>
                ) : (
                  <div className="mt-4 space-y-3">
                    {selectedDateSchedules.map((item) => (
                      <div
                        key={item.id}
                        className={`rounded-xl border p-4 ${getColorClass(
                          item.color
                        )}`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-semibold">{item.title}</p>
                          <span className="text-xs opacity-80">
                            {item.is_recurring ? "반복 일정" : "일회성 일정"}
                          </span>
                        </div>

                        <p className="mt-1 text-sm">
                          {formatTime(item.start_time)} ~{" "}
                          {formatTime(item.end_time)}
                        </p>

                        {item.location && (
                          <p className="mt-1 text-sm">📍 {item.location}</p>
                        )}

                        {item.memo && (
                          <p className="mt-1 text-sm opacity-80">{item.memo}</p>
                        )}

                        <div className="mt-3 flex gap-2">
                          <Link
                            href={`/personal/child/schedule?edit=${item.id}`}
                            className="rounded-lg border border-gray-300 bg-white px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                          >
                            수정하러 가기
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="mt-8 rounded-2xl border border-gray-200 bg-gray-50 p-5">
              <h3 className="text-lg font-semibold">캘린더 안내</h3>
              <div className="mt-3 space-y-2 text-sm text-gray-600">
                <p>• 반복 일정은 해당 요일에 맞춰 매주 달력에 표시돼요.</p>
                <p>• 일회성 일정은 지정한 날짜에만 표시돼요.</p>
                <p>• 하루 일정이 많으면 3개까지만 보이고, 나머지는 개수로 표시돼요.</p>
                <p>• 날짜를 클릭하면 아래에서 그날의 일정을 자세히 볼 수 있어요.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}