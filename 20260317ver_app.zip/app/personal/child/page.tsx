"use client";

import Link from "next/link";

const menuItems = [
  {
    title: "자녀 관리",
    description: "자녀 프로필을 등록하고 수정할 수 있어요.",
    href: "/personal/parent/children",
    emoji: "👧",
  },
  {
    title: "일정 관리",
    description: "반복 일정과 일회성 일정을 등록하고 관리해요.",
    href: "/personal/child/schedule",
    emoji: "🗓️",
  },
  {
    title: "시간표",
    description: "주간 시간표와 월간 캘린더로 일정을 한눈에 볼 수 있어요.",
    href: "/personal/child/timetable",
    emoji: "📚",
  },
  {
    title: "용돈 관리",
    description: "용돈 지급, 지출 내역, 현재 잔액을 확인할 수 있어요.",
    href: "/personal/child/allowance",
    emoji: "💰",
  },
  {
    title: "할 일 관리",
    description: "아이의 오늘 할 일과 완료 상태를 관리할 수 있어요.",
    href: "/personal/child/todo",
    emoji: "✅",
  },
];

export default function ChildPage() {
  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <section className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-gray-100">
          <h1 className="text-3xl font-bold text-gray-900">아이 관리</h1>
          <p className="mt-3 text-gray-600">
            자녀별 일정, 시간표, 용돈을 한곳에서 관리할 수 있어요.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/personal"
              className="rounded-2xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
            >
              개인 홈으로 이동
            </Link>
            <Link
              href="/personal/parent/children"
              className="rounded-2xl bg-gray-900 px-4 py-2 text-sm text-white hover:bg-gray-800"
            >
              자녀 관리 시작하기
            </Link>
          </div>
        </section>

        <section className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {menuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="group rounded-3xl bg-white p-6 shadow-sm ring-1 ring-gray-100 transition hover:-translate-y-1 hover:shadow-md"
            >
              <div className="text-3xl">{item.emoji}</div>
              <h2 className="mt-4 text-xl font-semibold text-gray-900">
                {item.title}
              </h2>
              <p className="mt-2 text-sm leading-6 text-gray-600">
                {item.description}
              </p>

              <div className="mt-5 text-sm font-medium text-gray-900">
                바로가기 →
              </div>
            </Link>
          ))}
        </section>
      </div>
    </main>
  );
}