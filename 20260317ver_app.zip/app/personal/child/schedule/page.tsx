"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@supabase/supabase-js";
import ChildSelector from "@/app/components/ChildSelector";
import ChildTopNav from "@/app/components/ChildTopNav";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

type Child = {
  id: string;
  name: string;
  created_at?: string;
};

type Schedule = {
  id: string;
  child_id: string | null;
  title: string;
  is_recurring: boolean;
  day_of_week: string | null;
  start_time: string | null;
  end_time: string | null;
  schedule_date: string | null;
  location: string | null;
  memo: string | null;
  color: string | null;
  created_at?: string;
};

const dayOptions = ["월", "화", "수", "목", "금", "토", "일"];

const colorOptions = [
  { label: "핑크", value: "pink" },
  { label: "노랑", value: "yellow" },
  { label: "파랑", value: "blue" },
  { label: "초록", value: "green" },
  { label: "보라", value: "purple" },
  { label: "회색", value: "gray" },
];

function formatTime(time: string | null) {
  if (!time) return "-";
  const parts = time.split(":");
  if (parts.length < 2) return time;
  return `${parts[0]}:${parts[1]}`;
}

function getColorClass(color: string | null) {
  switch (color) {
    case "pink":
      return "bg-pink-100 text-pink-700 border-pink-200";
    case "yellow":
      return "bg-yellow-100 text-yellow-700 border-yellow-200";
    case "blue":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "green":
      return "bg-green-100 text-green-700 border-green-200";
    case "purple":
      return "bg-purple-100 text-purple-700 border-purple-200";
    case "gray":
    default:
      return "bg-gray-100 text-gray-700 border-gray-200";
  }
}

function timeToMinutes(time: string | null) {
  if (!time) return null;
  const [h, m] = time.split(":").map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

function isTimeOverlapping(
  startA: string | null,
  endA: string | null,
  startB: string | null,
  endB: string | null
) {
  const aStart = timeToMinutes(startA);
  const aEnd = timeToMinutes(endA);
  const bStart = timeToMinutes(startB);
  const bEnd = timeToMinutes(endB);

  if (
    aStart === null ||
    aEnd === null ||
    bStart === null ||
    bEnd === null
  ) {
    return false;
  }

  return aStart < bEnd && bStart < aEnd;
}

export default function ChildSchedulePage() {
  const searchParams = useSearchParams();
  const editIdFromQuery = searchParams.get("edit");

  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChildId, setSelectedChildId] = useState("");

  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [isRecurring, setIsRecurring] = useState(true);
  const [dayOfWeek, setDayOfWeek] = useState("월");
  const [startTime, setStartTime] = useState("15:00");
  const [endTime, setEndTime] = useState("16:00");
  const [scheduleDate, setScheduleDate] = useState("");
  const [location, setLocation] = useState("");
  const [memo, setMemo] = useState("");
  const [color, setColor] = useState("pink");

  const childNameMap = useMemo(() => {
    return Object.fromEntries(children.map((child) => [child.id, child.name]));
  }, [children]);

  const colorLabelMap = useMemo(() => {
    return Object.fromEntries(
      colorOptions.map((item) => [item.value, item.label])
    );
  }, []);

  useEffect(() => {
    fetchChildren();
    fetchSchedules();
  }, []);

  useEffect(() => {
    if (!editIdFromQuery || schedules.length === 0) return;

    const target = schedules.find((item) => item.id === editIdFromQuery);
    if (target) {
      handleEdit(target);
    }
  }, [editIdFromQuery, schedules]);

  async function fetchChildren() {
    const { data, error } = await supabase
      .from("children")
      .select("*")
      .order("created_at", { ascending: true });

    if (error) {
      console.error("자녀 조회 오류:", error);
      setMessage(`자녀 목록을 불러오지 못했습니다: ${error.message}`);
      return;
    }

    const childList = (data as Child[]) || [];
    setChildren(childList);

    setSelectedChildId((prev) => {
      if (prev) return prev;
      return childList[0]?.id || "";
    });
  }

  async function fetchSchedules() {
    setLoading(true);

    const { data, error } = await supabase
      .from("schedules")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("일정 조회 오류:", error);
      setMessage(`일정 불러오기 실패: ${error.message}`);
      setLoading(false);
      return;
    }

    setSchedules((data as Schedule[]) || []);
    setLoading(false);
  }

  function resetForm() {
    setTitle("");
    setIsRecurring(true);
    setDayOfWeek("월");
    setStartTime("15:00");
    setEndTime("16:00");
    setScheduleDate("");
    setLocation("");
    setMemo("");
    setColor("pink");
    setEditingId(null);
    setMessage("");
  }

  function validateForm() {
    if (!selectedChildId) {
      setMessage("자녀를 먼저 등록하거나 선택해 주세요.");
      return false;
    }

    if (!title.trim()) {
      setMessage("일정명을 입력해 주세요.");
      return false;
    }

    if (!startTime || !endTime) {
      setMessage("시작 시간과 종료 시간을 입력해 주세요.");
      return false;
    }

    if (startTime >= endTime) {
      setMessage("종료 시간은 시작 시간보다 늦어야 합니다.");
      return false;
    }

    if (!isRecurring && !scheduleDate) {
      setMessage("일회성 일정은 날짜를 선택해 주세요.");
      return false;
    }

    return true;
  }

  function findConflict(): Schedule | null {
    const targetSchedules = schedules.filter((item) => {
      return item.id !== editingId && item.child_id === selectedChildId;
    });

    for (const item of targetSchedules) {
      if (isRecurring && item.is_recurring) {
        const sameDay = item.day_of_week === dayOfWeek;
        if (
          sameDay &&
          isTimeOverlapping(startTime, endTime, item.start_time, item.end_time)
        ) {
          return item;
        }
      }

      if (!isRecurring && !item.is_recurring) {
        const sameDate = item.schedule_date === scheduleDate;
        if (
          sameDate &&
          isTimeOverlapping(startTime, endTime, item.start_time, item.end_time)
        ) {
          return item;
        }
      }
    }

    return null;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setMessage("");

    if (!validateForm()) return;

    const conflict = findConflict();
    if (conflict) {
      setMessage(
        `겹치는 일정이 있습니다: ${conflict.title} (${formatTime(
          conflict.start_time
        )}~${formatTime(conflict.end_time)})`
      );
      return;
    }

    const payload = {
      child_id: selectedChildId,
      title: title.trim(),
      is_recurring: isRecurring,
      day_of_week: isRecurring ? dayOfWeek : null,
      start_time: startTime,
      end_time: endTime,
      schedule_date: isRecurring ? null : scheduleDate,
      location: location.trim() || null,
      memo: memo.trim() || null,
      color,
    };

    if (editingId) {
      const { error } = await supabase
        .from("schedules")
        .update(payload)
        .eq("id", editingId);

      if (error) {
        console.error("일정 수정 오류:", error);
        setMessage(`일정 수정 실패: ${error.message}`);
        return;
      }

      setMessage("일정이 수정되었습니다.");
    } else {
      const { error } = await supabase.from("schedules").insert([payload]);

      if (error) {
        console.error("일정 저장 오류:", error);
        setMessage(`일정 저장 실패: ${error.message}`);
        return;
      }

      setMessage("일정이 저장되었습니다.");
    }

    resetForm();
    await fetchSchedules();
  }

  function handleEdit(schedule: Schedule) {
    setEditingId(schedule.id);
    setSelectedChildId(schedule.child_id || "");
    setTitle(schedule.title);
    setIsRecurring(schedule.is_recurring);
    setDayOfWeek(schedule.day_of_week || "월");
    setStartTime(schedule.start_time || "15:00");
    setEndTime(schedule.end_time || "16:00");
    setScheduleDate(schedule.schedule_date || "");
    setLocation(schedule.location || "");
    setMemo(schedule.memo || "");
    setColor(schedule.color || "pink");
    setMessage("수정할 내용을 편집한 뒤 저장해 주세요.");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleDelete(id: string) {
    const ok = window.confirm("이 일정을 삭제할까요?");
    if (!ok) return;

    const { error } = await supabase.from("schedules").delete().eq("id", id);

    if (error) {
      console.error("일정 삭제 오류:", error);
      setMessage(`일정 삭제 실패: ${error.message}`);
      return;
    }

    if (editingId === id) {
      resetForm();
    }

    setMessage("일정이 삭제되었습니다.");
    await fetchSchedules();
  }

  const filteredSchedules = useMemo(() => {
    if (!selectedChildId) return schedules;
    return schedules.filter((item) => item.child_id === selectedChildId);
  }, [schedules, selectedChildId]);

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-5xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">아이 일정 관리</h1>
            <p className="mt-2 text-gray-600">자녀별 일정 등록 및 관리</p>

            <ChildTopNav />
          </div>

          <div className="flex flex-col gap-3 md:items-end">
            <ChildSelector
              value={selectedChildId}
              onChange={(id) => setSelectedChildId(id)}
            />
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm"
        >
          <h2 className="text-xl font-semibold">
            {editingId ? "일정 수정" : "일정 등록"}
          </h2>

          {message && <p className="mt-2 text-sm text-blue-600">{message}</p>}

          <div className="mt-4 grid gap-4">
            <div className="rounded-xl bg-gray-50 px-4 py-3 text-sm text-gray-700">
              선택된 자녀:{" "}
              <span className="font-semibold">
                {selectedChildId
                  ? childNameMap[selectedChildId] || "선택한 자녀"
                  : "선택 안 됨"}
              </span>
            </div>

            <input
              type="text"
              placeholder="일정명"
              className="rounded-xl border border-gray-300 px-4 py-3"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />

            <div className="flex items-center gap-3">
              <input
                id="isRecurring"
                type="checkbox"
                checked={isRecurring}
                onChange={(e) => setIsRecurring(e.target.checked)}
              />
              <label htmlFor="isRecurring" className="text-sm text-gray-700">
                반복 일정
              </label>
            </div>

            {isRecurring ? (
              <>
                <select
                  className="rounded-xl border border-gray-300 px-4 py-3"
                  value={dayOfWeek}
                  onChange={(e) => setDayOfWeek(e.target.value)}
                >
                  {dayOptions.map((day) => (
                    <option key={day} value={day}>
                      {day}
                    </option>
                  ))}
                </select>

                <div className="grid gap-4 md:grid-cols-2">
                  <input
                    type="time"
                    className="rounded-xl border border-gray-300 px-4 py-3"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                  />
                  <input
                    type="time"
                    className="rounded-xl border border-gray-300 px-4 py-3"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                  />
                </div>
              </>
            ) : (
              <>
                <input
                  type="date"
                  className="rounded-xl border border-gray-300 px-4 py-3"
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                />

                <div className="grid gap-4 md:grid-cols-2">
                  <input
                    type="time"
                    className="rounded-xl border border-gray-300 px-4 py-3"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                  />
                  <input
                    type="time"
                    className="rounded-xl border border-gray-300 px-4 py-3"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                  />
                </div>
              </>
            )}

            <input
              type="text"
              placeholder="장소"
              className="rounded-xl border border-gray-300 px-4 py-3"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />

            <textarea
              placeholder="메모"
              className="rounded-xl border border-gray-300 px-4 py-3"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
            />

            <div>
              <label className="mb-2 block text-sm font-medium text-gray-700">
                색상 선택
              </label>
              <select
                className="w-full rounded-xl border border-gray-300 px-4 py-3"
                value={color}
                onChange={(e) => setColor(e.target.value)}
              >
                {colorOptions.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>

              <div className="mt-3 flex items-center gap-3">
                <span
                  className={`inline-flex rounded-md border px-3 py-1 text-xs font-medium ${getColorClass(
                    color
                  )}`}
                >
                  선택한 색상 미리보기
                </span>
                <span className="text-sm text-gray-500">
                  {colorLabelMap[color] || "선택한 색상"}
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="flex-1 rounded-xl bg-black px-4 py-3 text-white disabled:cursor-not-allowed disabled:opacity-50"
                disabled={children.length === 0 || !selectedChildId}
              >
                {editingId ? "일정 수정 저장" : "일정 저장"}
              </button>

              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="rounded-xl border border-gray-300 px-4 py-3"
                >
                  취소
                </button>
              )}
            </div>
          </div>
        </form>

        <div className="mt-8 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-xl font-semibold">등록된 일정</h2>
            <p className="text-sm text-gray-500">
              {selectedChildId
                ? `${childNameMap[selectedChildId] || "선택한 자녀"} 일정`
                : "전체 일정"}
            </p>
          </div>

          {loading ? (
            <p className="mt-4">불러오는 중...</p>
          ) : filteredSchedules.length === 0 ? (
            <p className="mt-4 text-gray-500">등록된 일정이 없습니다.</p>
          ) : (
            <div className="mt-4 space-y-3">
              {filteredSchedules.map((schedule) => (
                <div
                  key={schedule.id}
                  className="rounded-xl border border-gray-200 p-4"
                >
                  <div className="mb-2 flex flex-wrap items-center gap-2">
                    <span
                      className={`inline-flex rounded-md border px-2 py-1 text-xs font-medium ${getColorClass(
                        schedule.color
                      )}`}
                    >
                      {colorLabelMap[schedule.color || "gray"] || "기본 색상"}
                    </span>

                    {schedule.is_recurring ? (
                      <span className="inline-block rounded-md bg-blue-100 px-2 py-1 text-xs text-blue-700">
                        반복 일정
                      </span>
                    ) : (
                      <span className="inline-block rounded-md bg-green-100 px-2 py-1 text-xs text-green-700">
                        일회성 일정
                      </span>
                    )}
                  </div>

                  <p className="font-semibold">{schedule.title}</p>

                  {schedule.is_recurring ? (
                    <p className="text-sm text-gray-600">
                      {schedule.day_of_week} / {formatTime(schedule.start_time)} ~{" "}
                      {formatTime(schedule.end_time)}
                    </p>
                  ) : (
                    <>
                      <p className="text-sm text-gray-600">
                        날짜: {schedule.schedule_date}
                      </p>
                      <p className="text-sm text-gray-600">
                        시간: {formatTime(schedule.start_time)} ~{" "}
                        {formatTime(schedule.end_time)}
                      </p>
                    </>
                  )}

                  {schedule.location && (
                    <p className="mt-1 text-sm text-gray-600">
                      📍 {schedule.location}
                    </p>
                  )}

                  {schedule.memo && (
                    <p className="mt-1 text-sm text-gray-700">
                      메모: {schedule.memo}
                    </p>
                  )}

                  <div className="mt-3 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleEdit(schedule)}
                      className="rounded-lg border border-gray-300 px-3 py-1 text-sm hover:bg-gray-50"
                    >
                      수정
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(schedule.id)}
                      className="rounded-lg border border-red-300 px-3 py-1 text-sm text-red-600 hover:bg-red-50"
                    >
                      삭제
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}