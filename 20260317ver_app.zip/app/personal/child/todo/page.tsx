"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type ChildRow = {
  id: string;
  name: string;
  points: number;
};

type TodoRow = {
  id: string;
  child_id: string;
  title: string;
  memo: string | null;
  due_date: string | null;
  reward_points: number;
  completed: boolean;
  completed_at: string | null;
  created_at: string;
};

export default function ChildTodoPage() {
  const [children, setChildren] = useState<ChildRow[]>([]);
  const [selectedChildId, setSelectedChildId] = useState("");
  const [todos, setTodos] = useState<TodoRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [completingId, setCompletingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [memo, setMemo] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [rewardPoints, setRewardPoints] = useState("100");

  useEffect(() => {
    fetchChildren();
  }, []);

  useEffect(() => {
    if (!selectedChildId) {
      setTodos([]);
      return;
    }
    fetchTodos(selectedChildId);
  }, [selectedChildId]);

  const selectedChild = useMemo(() => {
    return children.find((child) => child.id === selectedChildId) ?? null;
  }, [children, selectedChildId]);

  const incompleteTodos = useMemo(() => {
    return todos.filter((todo) => !todo.completed);
  }, [todos]);

  const completeTodos = useMemo(() => {
    return todos.filter((todo) => todo.completed);
  }, [todos]);

  const fetchChildren = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("children")
      .select("id, name, points")
      .order("created_at", { ascending: true });

    if (error) {
      console.error("children 조회 오류:", error);
      alert(`자녀 정보를 불러오지 못했어요.\n${error.message ?? ""}`);
      setLoading(false);
      return;
    }

    const rows = (data as ChildRow[]) ?? [];
    setChildren(rows);

    if (rows.length > 0) {
      setSelectedChildId(rows[0].id);
    }

    setLoading(false);
  };

  const fetchTodos = async (childId: string) => {
    const { data, error } = await supabase
      .from("todos")
      .select(
        "id, child_id, title, memo, due_date, reward_points, completed, completed_at, created_at"
      )
      .eq("child_id", childId)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("todos 조회 오류:", error);
      alert(`할 일 목록을 불러오지 못했어요.\n${error.message ?? ""}`);
      return;
    }

    setTodos((data as TodoRow[]) ?? []);
  };

  const resetForm = () => {
    setTitle("");
    setMemo("");
    setDueDate("");
    setRewardPoints("100");
  };

  const handleSubmit = async () => {
    if (!selectedChildId) {
      alert("먼저 자녀를 선택해 주세요.");
      return;
    }

    if (!title.trim()) {
      alert("할 일 제목을 입력해 주세요.");
      return;
    }

    const parsedRewardPoints = Number(rewardPoints);

    if (!Number.isFinite(parsedRewardPoints) || parsedRewardPoints < 0) {
      alert("보상 포인트는 0 이상의 숫자로 입력해 주세요.");
      return;
    }

    setSaving(true);

    const payload = {
      child_id: selectedChildId,
      title: title.trim(),
      memo: memo.trim() || null,
      due_date: dueDate || null,
      reward_points: Math.floor(parsedRewardPoints),
      completed: false,
      completed_at: null,
    };

    const { data, error, status, statusText } = await supabase
      .from("todos")
      .insert(payload)
      .select();

    console.log("todo insert payload:", payload);
    console.log("todo insert result:", { data, error, status, statusText });

    if (error) {
      alert(
        [
          "할 일 저장 실패",
          `message: ${error.message ?? "-"}`,
          `details: ${error.details ?? "-"}`,
          `hint: ${error.hint ?? "-"}`,
          `code: ${error.code ?? "-"}`,
          `status: ${status ?? "-"}`,
        ].join("\n")
      );
      setSaving(false);
      return;
    }

    resetForm();
    await fetchTodos(selectedChildId);
    setSaving(false);
    alert("할 일이 등록되었어요.");
  };

  const handleCompleteTodo = async (todoId: string) => {
    if (!selectedChildId) {
      alert("자녀 정보가 없어요.");
      return;
    }

    setCompletingId(todoId);

    try {
      const { data: todoData, error: todoError } = await supabase
        .from("todos")
        .select("id, child_id, completed, reward_points")
        .eq("id", todoId)
        .single();

      if (todoError || !todoData) {
        alert(
          [
            "할 일 정보를 확인하지 못했어요.",
            `message: ${todoError?.message ?? "-"}`,
            `details: ${todoError?.details ?? "-"}`,
            `hint: ${todoError?.hint ?? "-"}`,
            `code: ${todoError?.code ?? "-"}`,
          ].join("\n")
        );
        setCompletingId(null);
        return;
      }

      if (todoData.completed) {
        alert("이미 완료된 할 일이에요.");
        setCompletingId(null);
        return;
      }

      const reward = Number(todoData.reward_points ?? 0);

      const { data: childData, error: childError } = await supabase
        .from("children")
        .select("id, points")
        .eq("id", todoData.child_id)
        .single();

      if (childError || !childData) {
        alert(
          [
            "자녀 포인트를 확인하지 못했어요.",
            `message: ${childError?.message ?? "-"}`,
            `details: ${childError?.details ?? "-"}`,
            `hint: ${childError?.hint ?? "-"}`,
            `code: ${childError?.code ?? "-"}`,
          ].join("\n")
        );
        setCompletingId(null);
        return;
      }

      const nextPoints = Number(childData.points ?? 0) + reward;

      const { error: updateTodoError } = await supabase
        .from("todos")
        .update({
          completed: true,
          completed_at: new Date().toISOString(),
        })
        .eq("id", todoId)
        .eq("completed", false);

      if (updateTodoError) {
        alert(
          [
            "할 일 완료 처리에 실패했어요.",
            `message: ${updateTodoError.message ?? "-"}`,
            `details: ${updateTodoError.details ?? "-"}`,
            `hint: ${updateTodoError.hint ?? "-"}`,
            `code: ${updateTodoError.code ?? "-"}`,
          ].join("\n")
        );
        setCompletingId(null);
        return;
      }

      const { error: updateChildError } = await supabase
        .from("children")
        .update({ points: nextPoints })
        .eq("id", todoData.child_id);

      if (updateChildError) {
        alert(
          [
            "포인트 적립에 실패했어요.",
            `message: ${updateChildError.message ?? "-"}`,
            `details: ${updateChildError.details ?? "-"}`,
            `hint: ${updateChildError.hint ?? "-"}`,
            `code: ${updateChildError.code ?? "-"}`,
          ].join("\n")
        );
        setCompletingId(null);
        return;
      }

      setChildren((prev) =>
        prev.map((child) =>
          child.id === todoData.child_id ? { ...child, points: nextPoints } : child
        )
      );

      await fetchTodos(selectedChildId);
      alert(`${reward}P 적립 완료!`);
    } finally {
      setCompletingId(null);
    }
  };

  const handleDeleteTodo = async (todoId: string) => {
    if (!selectedChildId) return;

    const ok = window.confirm("이 할 일을 삭제할까요?");
    if (!ok) return;

    setDeletingId(todoId);

    const { error } = await supabase.from("todos").delete().eq("id", todoId);

    if (error) {
      alert(
        [
          "할 일 삭제에 실패했어요.",
          `message: ${error.message ?? "-"}`,
          `details: ${error.details ?? "-"}`,
          `hint: ${error.hint ?? "-"}`,
          `code: ${error.code ?? "-"}`,
        ].join("\n")
      );
      setDeletingId(null);
      return;
    }

    await fetchTodos(selectedChildId);
    setDeletingId(null);
  };

  const formatDate = (value: string | null) => {
    if (!value) return "-";
    return new Date(value).toLocaleDateString("ko-KR");
  };

  const formatDateTime = (value: string | null) => {
    if (!value) return "-";
    return new Date(value).toLocaleString("ko-KR");
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-gray-50 px-6 py-12">
        <div className="mx-auto max-w-5xl">불러오는 중...</div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">할 일 관리</h1>
            <p className="mt-2 text-sm text-gray-600">
              자녀별 할 일을 등록하고, 완료하면 포인트를 적립할 수 있어요.
            </p>
          </div>

          <div className="flex gap-2">
            <Link
              href="/personal/child"
              className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
            >
              아이 관리로 이동
            </Link>
            <Link
              href="/personal"
              className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"
            >
              홈으로 이동
            </Link>
          </div>
        </div>

        {selectedChild && (
          <div className="rounded-2xl bg-white px-5 py-4 shadow-sm ring-1 ring-gray-100">
            <p className="text-sm text-gray-500">{selectedChild.name} 현재 포인트</p>
            <p className="mt-1 text-2xl font-bold text-blue-600">
              {selectedChild.points}P
            </p>
          </div>
        )}

        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
          <label className="mb-2 block text-sm font-medium text-gray-700">
            자녀 선택
          </label>
          <select
            value={selectedChildId}
            onChange={(e) => setSelectedChildId(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
          >
            {children.length === 0 ? (
              <option value="">등록된 자녀가 없어요</option>
            ) : (
              children.map((child) => (
                <option key={child.id} value={child.id}>
                  {child.name}
                </option>
              ))
            )}
          </select>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">할 일 등록</h2>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="mb-2 block text-sm font-medium text-gray-700">
                할 일 제목
              </label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="예: 영어 숙제 하기"
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-gray-700">
                마감일
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-gray-700">
                보상 포인트
              </label>
              <input
                type="number"
                min={0}
                step={1}
                value={rewardPoints}
                onChange={(e) => setRewardPoints(e.target.value)}
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="mb-2 block text-sm font-medium text-gray-700">
                메모
              </label>
              <textarea
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                rows={4}
                placeholder="예: 끝나면 엄마한테 보여주기"
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-500"
              />
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={!selectedChildId || saving}
            className={`mt-5 rounded-2xl px-5 py-3 text-sm font-semibold text-white transition ${
              !selectedChildId || saving
                ? "cursor-not-allowed bg-gray-300"
                : "bg-gray-900 hover:bg-gray-800"
            }`}
          >
            {saving ? "저장 중..." : "할 일 등록"}
          </button>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">진행 중인 할 일</h2>
              <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700">
                {incompleteTodos.length}개
              </span>
            </div>

            {incompleteTodos.length === 0 ? (
              <p className="mt-4 text-sm text-gray-500">진행 중인 할 일이 없어요.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {incompleteTodos.map((todo) => (
                  <div
                    key={todo.id}
                    className="rounded-2xl border border-gray-200 p-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-base font-semibold text-gray-900">
                          {todo.title}
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          마감일: {formatDate(todo.due_date)}
                        </p>
                        <p className="mt-1 text-sm text-blue-600">
                          보상: {todo.reward_points}P
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleCompleteTodo(todo.id)}
                          disabled={completingId === todo.id}
                          className={`rounded-xl px-3 py-2 text-sm font-medium text-white ${
                            completingId === todo.id
                              ? "cursor-not-allowed bg-gray-300"
                              : "bg-emerald-600 hover:bg-emerald-700"
                          }`}
                        >
                          {completingId === todo.id ? "처리 중..." : "완료"}
                        </button>

                        <button
                          onClick={() => handleDeleteTodo(todo.id)}
                          disabled={deletingId === todo.id}
                          className={`rounded-xl px-3 py-2 text-sm font-medium ${
                            deletingId === todo.id
                              ? "cursor-not-allowed bg-gray-100 text-gray-400"
                              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                          }`}
                        >
                          삭제
                        </button>
                      </div>
                    </div>

                    {todo.memo && (
                      <div className="mt-3 rounded-xl bg-gray-50 px-3 py-3 text-sm text-gray-600">
                        {todo.memo}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">완료된 할 일</h2>
              <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">
                {completeTodos.length}개
              </span>
            </div>

            {completeTodos.length === 0 ? (
              <p className="mt-4 text-sm text-gray-500">완료된 할 일이 없어요.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {completeTodos.map((todo) => (
                  <div
                    key={todo.id}
                    className="rounded-2xl border border-gray-200 bg-gray-50 p-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-base font-semibold text-gray-800 line-through">
                          {todo.title}
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          완료일: {formatDateTime(todo.completed_at)}
                        </p>
                        <p className="mt-1 text-sm text-blue-600">
                          적립: {todo.reward_points}P
                        </p>
                      </div>

                      <button
                        onClick={() => handleDeleteTodo(todo.id)}
                        disabled={deletingId === todo.id}
                        className={`rounded-xl px-3 py-2 text-sm font-medium ${
                          deletingId === todo.id
                            ? "cursor-not-allowed bg-white text-gray-400"
                            : "bg-white text-gray-700 hover:bg-gray-100"
                        }`}
                      >
                        삭제
                      </button>
                    </div>

                    {todo.memo && (
                      <div className="mt-3 rounded-xl bg-white px-3 py-3 text-sm text-gray-600">
                        {todo.memo}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}