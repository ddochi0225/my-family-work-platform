import {
  CalendarDays,
  Clock3,
  MapPin,
} from "lucide-react";
import { requireChild } from "@/lib/auth/requireChild";
import { createServerSupabase } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type ScheduleRow = {
  id: string;
  child_id: string;
  title: string;
  is_recurring: boolean;
  day_of_week: string | null;
  start_time: string | null;
  end_time: string | null;
  schedule_date: string | null;
  location: string | null;
  memo: string | null;
  color: string | null;
};

const DAY_LABELS = ["일", "월", "화", "수", "목", "금", "토"];
const DAY_KEYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];

function toDateStringLocal(date: Date) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDate(dateString?: string | null) {
  if (!dateString) return "";
  const date = new Date(`${dateString}T00:00:00`);
  return `${date.getMonth() + 1}월 ${date.getDate()}일`;
}

function formatTimeRange(start?: string | null, end?: string | null) {
  if (!start && !end) return "시간 미정";
  if (start && end) return `${start.slice(0, 5)} ~ ${end.slice(0, 5)}`;
  if (start) return `${start.slice(0, 5)} ~`;
  return `~ ${end?.slice(0, 5)}`;
}

function getDayLabelFromKey(day?: string | null) {
  switch (day) {
    case "sunday":
      return "일요일";
    case "monday":
      return "월요일";
    case "tuesday":
      return "화요일";
    case "wednesday":
      return "수요일";
    case "thursday":
      return "목요일";
    case "friday":
      return "금요일";
    case "saturday":
      return "토요일";
    default:
      return "";
  }
}

function getColorClass(color?: string | null) {
  switch (color) {
    case "pink":
      return "border-pink-200 bg-pink-50";
    case "yellow":
      return "border-yellow-200 bg-yellow-50";
    case "blue":
      return "border-blue-200 bg-blue-50";
    case "green":
      return "border-green-200 bg-green-50";
    case "purple":
      return "border-purple-200 bg-purple-50";
    case "gray":
    default:
      return "border-gray-200 bg-gray-50";
  }
}

export default async function ChildSchedulePage() {
  const profile = await requireChild();
  const supabase = await createServerSupabase();

  if (!profile.child_id) {
    return (
      <div className="space-y-4">
        <section className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
          <h1 className="text-2xl font-bold text-slate-900">내 일정</h1>
          <p className="mt-2 text-sm text-slate-500">
            아직 연결된 자녀 프로필이 없어요.
          </p>
        </section>
      </div>
    );
  }

  const { data, error } = await supabase
    .from("schedules")
    .select(
      "id, child_id, title, is_recurring, day_of_week, start_time, end_time, schedule_date, location, memo, color"
    )
    .eq("child_id", profile.child_id)
    .order("schedule_date", { ascending: true });

  const items = (data as ScheduleRow[]) ?? [];
  const now = new Date();
  const todayString = toDateStringLocal(now);
  const todayDayKey = DAY_KEYS[now.getDay()];
  const todayLabel = `${formatDate(todayString)} · ${DAY_LABELS[now.getDay()]}요일`;

  const todayItems = items
    .filter((item) => {
      if (item.is_recurring) return item.day_of_week === todayDayKey;
      return item.schedule_date === todayString;
    })
    .sort((a, b) => (a.start_time ?? "99:99").localeCompare(b.start_time ?? "99:99"));

  const upcomingItems = items
    .filter((item) => {
      if (item.is_recurring) return item.day_of_week !== todayDayKey;
      return !!item.schedule_date && item.schedule_date > todayString;
    })
    .sort((a, b) => {
      const aDate = a.schedule_date ?? "9999-12-31";
      const bDate = b.schedule_date ?? "9999-12-31";
      if (aDate !== bDate) return aDate.localeCompare(bDate);
      return (a.start_time ?? "99:99").localeCompare(b.start_time ?? "99:99");
    })
    .slice(0, 12);

  return (
    <div className="space-y-6">
      {error ? (
        <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
          일정 조회 오류: {error.message ?? "알 수 없는 오류"}
        </section>
      ) : null}

      <section className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-semibold tracking-wide text-sky-600">{todayLabel}</p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-900">
              내 일정
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              오늘 일정과 앞으로의 일정을 확인해요.
            </p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <SummaryCard title="오늘 일정" value={`${todayItems.length}개`} />
        <SummaryCard title="다가오는 일정" value={`${upcomingItems.length}개`} />
        <SummaryCard title="반복 일정" value={`${items.filter((item) => item.is_recurring).length}개`} />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel
          title="오늘 일정"
          icon={<CalendarDays className="h-5 w-5" />}
          badge={`${todayItems.length}개`}
        >
          {todayItems.length === 0 ? (
            <EmptyState text="오늘 등록된 일정이 없어요." />
          ) : (
            <div className="space-y-3">
              {todayItems.map((item) => (
                <ScheduleCard key={item.id} item={item} />
              ))}
            </div>
          )}
        </Panel>

        <Panel
          title="다가오는 일정"
          icon={<Clock3 className="h-5 w-5" />}
          badge={`${upcomingItems.length}개`}
        >
          {upcomingItems.length === 0 ? (
            <EmptyState text="다가오는 일정이 없어요." />
          ) : (
            <div className="space-y-3">
              {upcomingItems.map((item) => (
                <ScheduleCard key={item.id} item={item} />
              ))}
            </div>
          )}
        </Panel>
      </section>
    </div>
  );
}

function ScheduleCard({ item }: { item: ScheduleRow }) {
  return (
    <div className={`rounded-xl border px-4 py-3 ${getColorClass(item.color)}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-slate-900">{item.title}</p>

          <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-500">
            <span>{formatTimeRange(item.start_time, item.end_time)}</span>
            {item.is_recurring ? (
              <span>{getDayLabelFromKey(item.day_of_week)} 반복</span>
            ) : item.schedule_date ? (
              <span>{formatDate(item.schedule_date)}</span>
            ) : null}
          </div>

          {item.location ? (
            <p className="mt-2 flex items-center gap-1 text-xs text-slate-400">
              <MapPin className="h-3.5 w-3.5" />
              {item.location}
            </p>
          ) : null}

          {item.memo ? <p className="mt-2 text-xs text-slate-500">{item.memo}</p> : null}
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-medium text-slate-500">{title}</p>
      <p className="mt-1 text-3xl font-bold tracking-tight text-slate-900">{value}</p>
    </div>
  );
}

function Panel({
  title,
  icon,
  badge,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  badge?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-600">
            {icon}
          </div>
          <h2 className="text-lg font-bold text-slate-900">{title}</h2>
        </div>
        {badge ? (
          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
            {badge}
          </span>
        ) : null}
      </div>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="rounded-xl border border-dashed border-gray-300 bg-slate-50 px-4 py-10 text-center text-sm text-slate-400">
      {text}
    </div>
  );
}