type ChildPageHeaderProps = {
  dateLabel?: string;
  title: string;
  description: string;
  tone?: "home" | "todo" | "schedule" | "timetable" | "goals" | "allowance";
  rightSlot?: React.ReactNode;
};

const toneClassMap: Record<NonNullable<ChildPageHeaderProps["tone"]>, string> = {
  home: "from-sky-50 via-indigo-50 to-violet-50 border-sky-100",
  todo: "from-cyan-50 via-sky-50 to-emerald-50 border-cyan-100",
  schedule: "from-blue-50 via-indigo-50 to-violet-50 border-blue-100",
  timetable: "from-violet-50 via-fuchsia-50 to-pink-50 border-violet-100",
  goals: "from-violet-50 via-indigo-50 to-sky-50 border-violet-100",
  allowance: "from-amber-50 via-orange-50 to-yellow-50 border-amber-100",
};

export default function ChildPageHeader({
  dateLabel,
  title,
  description,
  tone = "home",
  rightSlot,
}: ChildPageHeaderProps) {
  return (
    <section
      className={`rounded-[28px] border bg-gradient-to-r px-6 py-5 shadow-sm ${toneClassMap[tone]}`}
    >
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          {dateLabel ? (
            <p className="text-sm font-bold text-blue-600">{dateLabel}</p>
          ) : null}
          <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-slate-900">
            {title}
          </h1>
          <p className="mt-2 text-sm text-slate-600">{description}</p>
        </div>

        {rightSlot ? <div className="flex flex-wrap gap-2">{rightSlot}</div> : null}
      </div>
    </section>
  );
}