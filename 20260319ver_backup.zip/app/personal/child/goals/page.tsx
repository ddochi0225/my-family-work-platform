import { requireChild } from "@/lib/auth/requireChild";
import { createServerSupabase } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type GoalRow = {
  id: string;
  child_id: string;
  title: string;
  target_points: number;
  reward: string | null;
  achieved: boolean;
  achieved_at: string | null;
  reward_given: boolean;
  reward_given_at: string | null;
  created_at: string;
};

type PointRow = {
  points: number;
};

export default async function ChildGoalsPage() {
  const profile = await requireChild();
  const supabase = await createServerSupabase();

  const { data: goals } = await supabase
    .from("point_goals")
    .select(
      "id, child_id, title, target_points, reward, achieved, achieved_at, reward_given, reward_given_at, created_at"
    )
    .eq("child_id", profile.child_id)
    .order("created_at", { ascending: false });

  const { data: points } = await supabase
    .from("point_histories")
    .select("points")
    .eq("child_id", profile.child_id);

  const totalPoints =
    ((points as PointRow[]) ?? []).reduce(
      (sum, item) => sum + Number(item.points ?? 0),
      0
    ) ?? 0;

  const goalItems = ((goals as GoalRow[]) ?? []).map((goal) => {
    const achievedNow = totalPoints >= goal.target_points;
    return {
      ...goal,
      achievedNow,
      percent: Math.min((totalPoints / goal.target_points) * 100, 100),
    };
  });

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900">내 목표 🎯</h2>
        <p className="mt-2 text-sm text-gray-500">
          포인트를 모아서 목표를 달성해 보세요.
        </p>
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <p className="text-sm text-gray-500">현재 포인트</p>
        <p className="mt-2 text-3xl font-bold text-gray-900">{totalPoints}P</p>
      </section>

      {goalItems.length === 0 ? (
        <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <p className="text-sm text-gray-500">아직 등록된 목표가 없어요.</p>
        </section>
      ) : (
        goalItems.map((goal) => (
          <section
            key={goal.id}
            className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{goal.title}</h3>
                {goal.reward ? (
                  <p className="mt-1 text-sm text-gray-500">보상: {goal.reward}</p>
                ) : null}
              </div>

              {goal.reward_given ? (
                <span className="rounded-full bg-sky-50 px-2 py-1 text-xs text-sky-700">
                  보상 받음
                </span>
              ) : goal.achievedNow ? (
                <span className="rounded-full bg-emerald-50 px-2 py-1 text-xs text-emerald-700">
                  목표 달성
                </span>
              ) : (
                <span className="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600">
                  진행 중
                </span>
              )}
            </div>

            <div className="mt-4 h-3 rounded-full bg-gray-200">
              <div
                className="h-3 rounded-full bg-violet-600"
                style={{ width: `${goal.percent}%` }}
              />
            </div>

            <p className="mt-2 text-sm text-gray-600">
              {totalPoints} / {goal.target_points}P
            </p>

            {goal.achievedNow && !goal.reward_given ? (
              <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">
                <p className="font-semibold">🎉 목표를 달성했어요!</p>
                <p className="mt-1">부모님께 보여주고 보상을 받아보세요.</p>
              </div>
            ) : null}

            {goal.reward_given ? (
              <div className="mt-3 rounded-xl border border-sky-200 bg-sky-50 p-3 text-sm text-sky-700">
                <p className="font-semibold">보상을 받았어요 🎁</p>
                <p className="mt-1">
                  {goal.reward ? `${goal.reward} 보상이 지급되었어요.` : "보상이 지급되었어요."}
                </p>
              </div>
            ) : null}
          </section>
        ))
      )}
    </div>
  );
}