import { requireChild } from "@/lib/auth/requireChild";

export default async function ChildSchedulePage() {
  await requireChild();

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900">내 일정</h2>
        <p className="mt-2 text-sm text-gray-500">
          오늘과 앞으로의 일정을 확인할 수 있어요.
        </p>
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">오늘 일정</h3>
          <span className="rounded-full bg-violet-50 px-2 py-1 text-xs text-violet-600">
            0개
          </span>
        </div>

        <p className="mt-3 text-sm text-gray-500">
          오늘 등록된 일정이 없어요.
        </p>
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h3 className="font-semibold text-gray-900">다가오는 일정</h3>
        <p className="mt-3 text-sm text-gray-500">
          아직 예정된 일정이 없어요.
        </p>
      </section>
    </div>
  );
}