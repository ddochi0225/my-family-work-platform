"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase/client";
import {
  CalendarDays,
  CheckSquare,
  Coins,
  Home,
  LogOut,
  TimerReset,
} from "lucide-react";

const menus = [
  {
    href: "/personal/child",
    label: "홈",
    icon: Home,
    match: (pathname: string) => pathname === "/personal/child",
  },
  {
    href: "/personal/child/todo",
    label: "할 일",
    icon: CheckSquare,
    match: (pathname: string) => pathname.startsWith("/personal/child/todo"),
  },
  {
    href: "/personal/child/schedule",
    label: "일정",
    icon: CalendarDays,
    match: (pathname: string) =>
      pathname.startsWith("/personal/child/schedule"),
  },
  {
    href: "/personal/child/timetable",
    label: "시간표",
    icon: TimerReset,
    match: (pathname: string) =>
      pathname.startsWith("/personal/child/timetable"),
  },
  {
    href: "/personal/child/allowance",
    label: "포인트",
    icon: Coins,
    match: (pathname: string) =>
      pathname.startsWith("/personal/child/allowance"),
  },
];

export default function ChildSidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  return (
    <aside className="hidden w-64 shrink-0 rounded-3xl bg-white p-5 shadow-sm lg:block">
      <div className="mb-6">
        <p className="text-xs font-semibold uppercase tracking-wider text-sky-500">
          Child Mode
        </p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">자녀 메뉴</h2>
        <p className="mt-1 text-sm text-slate-500">
          오늘 할 일과 시간표를 쉽게 확인해요.
        </p>
      </div>

      <nav className="space-y-2">
        {menus.map((menu) => {
          const active = menu.match(pathname);
          const Icon = menu.icon;

          return (
            <Link
              key={menu.href}
              href={menu.href}
              className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition ${
                active
                  ? "bg-sky-50 text-sky-700 ring-1 ring-sky-200"
                  : "text-slate-700 hover:bg-slate-50"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{menu.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mt-8 border-t border-slate-100 pt-4">
        <button
          type="button"
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium text-rose-600 transition hover:bg-rose-50"
        >
          <LogOut className="h-5 w-5" />
          <span>로그아웃</span>
        </button>
      </div>
    </aside>
  );
}