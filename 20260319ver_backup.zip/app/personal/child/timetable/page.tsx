import { requireChild } from "@/lib/auth/requireChild";
import { createServerSupabase } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const DAYS = [
  { key: "monday", label: "월요일" },
  { key: "tuesday", label: "화요일" },
  { key: "wednesday", label: "수요일" },
  { key: "thursday", label: "목요일" },
  { key: "friday", label: "금요일" },
  { key: "saturday", label: "토요일" },
  { key: "sunday", label: "일요일" },
];

type TimetableRow = {
  id: string;
  child_id: string;
  day_of_week: string;
  start_time: string;
  end_time: string;
  subject: string;
  location: string | null;
  color: string | null;
  repeat_type: string | null;
};

export default async function ChildTimetablePage() {
  const profile = await requireChild();
  const supabase = await createServerSupabase();

  if (!profile.child_id) {
    return (
      <div className="space-y-4">
        <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h2 className="text-lg font-bold text-gray-900">내 시간표</h2>
          <p className="mt-2 text-sm text-gray-500">
            아직 연결된 자녀 프로필이 없어요.
          </p>
        </section>
      </div>
    );
  }

  const { data, error } = await supabase
    .from("timetables")
    .select(
      "id, child_id, day_of_week, start_time, end_time, subject, location, color, repeat_type"
    )
    .eq("child_id", profile.child_id)
    .order("start_time", { ascending: true });

  let pageMessage = "";

  if (error) {
    pageMessage = `시간표 조회 오류: ${error.message ?? "알 수 없는 오류"}`;
  }

  const items = (data as TimetableRow[]) ?? [];

  return (
    <div className="space-y-4">
      {pageMessage ? (
        <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
          {pageMessage}
        </section>
      ) : null}

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900">내 시간표</h2>
        <p className="mt-2 text-sm text-gray-500">
          이번 주 시간표를 확인할 수 있어요.
        </p>
      </section>

      {DAYS.map((day) => {
        const dayItems = items.filter((item) => item.day_of_week === day.key);

        return (
          <section
            key={day.key}
            className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm"
          >
            <h3 className="font-semibold text-gray-900">{day.label}</h3>

            {dayItems.length === 0 ? (
              <p className="mt-3 text-sm text-gray-500">등록된 일정이 없어요.</p>
            ) : (
              <div className="mt-3 space-y-3">
                {dayItems.map((item) => (
                  <div
                    key={item.id}
                    className={`rounded-xl border p-3 ${getColorCardClass(item.color)}`}
                  >
                    <p className="text-sm font-semibold text-gray-900">
                      {item.subject}
                    </p>
                    <p className="mt-1 text-sm text-gray-600">
                      {item.start_time} ~ {item.end_time}
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      {getRepeatTypeLabel(item.repeat_type)}
                    </p>
                    {item.location ? (
                      <p className="mt-1 text-xs text-gray-500">{item.location}</p>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}

function getColorCardClass(color: string | null) {
  switch (color) {
    case "sky":
      return "border-sky-200 bg-sky-50";
    case "violet":
      return "border-violet-200 bg-violet-50";
    case "emerald":
      return "border-emerald-200 bg-emerald-50";
    case "amber":
      return "border-amber-200 bg-amber-50";
    case "rose":
      return "border-rose-200 bg-rose-50";
    case "slate":
      return "border-slate-200 bg-slate-50";
    default:
      return "border-gray-100 bg-gray-50";
  }
}

function getRepeatTypeLabel(repeatType: string | null) {
  switch (repeatType) {
    case "weekday":
      return "평일 반복";
    case "weekend":
      return "주말 반복";
    case "once":
      return "1회성 표시";
    case "weekly":
    default:
      return "매주 반복";
  }
}